import requests
from random import choice
from io import BytesIO
from base64 import encodebytes
from PIL import Image
from config import API_KEY
from lol import get_city


def get_gamemode(mode: str, modification: str):
    responses = {
        'default': get_city(5),
        'infinity': get_city(1)
    }
    return responses[mode]


def get_response_image(image_path):
    pil_img = Image.open(image_path, mode='r')
    byte_arr = BytesIO()
    pil_img.save(byte_arr, format='PNG')
    encoded_img = encodebytes(byte_arr.getvalue()).decode('ascii')
    return encoded_img


def get_img(lat, lon):

    lat = str(float(lat) + choice([-0.016, 0.016]))
    lon = str(float(lon) + choice([-0.016, 0.016]))

    url = f'https://static-maps.yandex.ru/v1?ll={lon},{lat}&spn=0.02,0.02&size=600,400&apikey={API_KEY}'
    resp_for_sec = requests.get(url) # , stream=True

    return resp_for_sec.content

