async function makeRequest(url, method = 'GET', data = null, headers = {}) {
    try {
        const config = {
            method,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            }
        };

        if (data) {
            config.body = JSON.stringify(data);
        }

        const response = await fetch(url, config);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();

    } catch (error) {
        console.error('Request failed:', error);
        throw error;
    }
};


function fetchData(callback, postData) {
    makeRequest('http://127.0.0.1:5000/authorization?type=registration', 'POST', postData)
        .then(data => {
            val = data;
            callback(data)
        });
}


function processDataLater(data) {
    if (data.code === '200') {
        console.log('nice')
    }
};


const login = document.getElementById('login')
const password = document.getElementById('password')
const enter = document.getElementById('enter')


enter.onclick = async () => {
    if (login.value) {
        if (password.value) {
            let postData = {
                login: login.value,
                password: password.value
            }
            fetchData(processDataLater, postData)
        }
    }
}

