const allGames = document.getElementById('allGames')
const rAnswer = document.getElementById('rAnswer')
const CD = document.getElementById('CD')


fetch('/user/info?type=games')
    .then(r => r.text())
    .then(points => {
        allGames.textContent = points;
    });

fetch('/user/info?type=point')
    .then(r => r.text())
    .then(points => {
        rAnswer.textContent = points;
    });

fetch('/user/info?type=KD')
    .then(r => r.text())
    .then(points => {
        CD.textContent = points;
    });
