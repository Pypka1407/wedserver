from flask import Flask, render_template, request as flask_request, redirect, send_file, make_response
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash  # для баз данных
from game import get_img, get_gamemode
from io import BytesIO


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///default_base.db'
db = SQLAlchemy(app)


# моя база данных
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    password = db.Column(db.String, nullable=False)
    games = db.Column(db.Integer, default=0)
    point = db.Column(db.Integer, default=0)
    all_ans = db.Column(db.Integer, default=0)


app.app_context().push()
db.create_all()


# api
@app.route('/api/game', methods=['POST'])
def get_post():
    if flask_request.method == 'POST':
        game_type = flask_request.args.get('type')
        if game_type == 'start':
            data = flask_request.get_json()
            game_mode = data['gamemode']
            gameModification = data['gameModification']
            return get_gamemode(game_mode, gameModification)
        elif game_type == 'ending':
            if 'login' in flask_request.cookies and 'password' in flask_request.cookies:
                login = flask_request.cookies.get('login')
                password = flask_request.cookies.get('password')
                data = flask_request.get_json()
                all_ans = data['all']
                right_ans = data['right']

                user = User.query.filter(User.name == login and User.password == password).first()
                user.games += 1
                user.all_ans += int(all_ans)
                user.point += int(right_ans)
                db.session.commit()
                return { 'code': '200' }


@app.route('/api/game-map', methods=['GET'])
def get_map():
    if flask_request.method == 'GET':
        bar = flask_request.args.to_dict()
        lat, lon = bar.values()
        print(lat, lon)
        response = get_img(lat, lon)

        return send_file(
            BytesIO(response),
            mimetype='image/png')


@app.route('/authorization', methods=['POST', 'GET'])
def login_registration():
    if flask_request.method == 'POST':
        authorization_typerequest = flask_request.args.get('type')
        data = flask_request.get_json()

        if authorization_typerequest == 'login':
            login = data['login']
            password = data['password']
            
            try:
                passw = db.session.query(User.password).filter(User.name == login).first()[0]
                if check_password_hash(passw, password):
                    resp = make_response({ 'code': '200', 'login': f'{login}' })
                    resp.set_cookie('login', login)
                    resp.set_cookie('password', generate_password_hash(password))
                    return resp
                else:
                    return { 'code': '401', 'mes': 'password is wrong' }
            except TypeError:
                return { 'code': '402', 'mes': 'not in db' }
        
        elif authorization_typerequest == 'registration':
            login = data['login']
            password = generate_password_hash(data['password'])
            try:
                x = db.session.query(User.name).filter(User.name == login).first()
                if x == None:
                    new_us = User(name = login, password = password)
                    db.session.add(new_us)
                    db.session.commit()
                    response = make_response({ 'code': '200', 'login': f'{login}' })
                    response.set_cookie("login", login)
                    response.set_cookie("password", password)
                    return { 'code': '200', 'login': f'{login}' }
                else:
                    return { 'error': 'already in db' }
            except:
                return { 'error': 'unexpected error' }


@app.route('/user/info', methods=['GET'])
def get_us_score():
    if flask_request.method == 'GET':

        if 'login' in flask_request.cookies and 'password' in flask_request.cookies:

            login = flask_request.cookies.get('login')
            password = flask_request.cookies.get('password')
            typerequest = flask_request.args.get('type')

            if typerequest == 'games':
                return str(db.session.query(User.games).filter(
                    User.name == login and User.password == password).first()[0])
            
            elif typerequest == 'point':
                return str(db.session.query(User.point).filter(
                    User.name == login and User.password == password).first()[0])
            
            elif typerequest == 'KD':
                x = db.session.query(User.all_ans).filter(User.name == login and User.password == password).first()[0]
                if x == 0:
                    return '0'
                else:
                    return str(round(
                        (db.session.query(User.point).filter(
                            User.name == login and User.password == password).first()[0] / x), 2))
        else:
            return '#'


# фронт
@app.route('/')
@app.route('/home')
def index():
    return render_template('home.html')

@app.route('/game')
def game():
    return render_template('game.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/about/game')
def abgame():
    return render_template('abgame.html')

@app.route('/user')
def player():
    if 'login' in flask_request.cookies and 'password' in flask_request.cookies:
        return render_template('user.html')
    else:
        return redirect('/login')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/registration')
def registration():
    return render_template('registration.html')


if __name__ == '__main__':
    app.run(debug=True, port=5000, host="127.0.0.1")
