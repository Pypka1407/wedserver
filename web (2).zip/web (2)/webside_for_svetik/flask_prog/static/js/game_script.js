async function makeRequest(url, method = 'GET', data = null, headers = {}) {
    try {
        const config = {
            method,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            }
        };

        if (data) {
            config.body = JSON.stringify(data);
        }

        const response = await fetch(url, config);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();

    } catch (error) {
        console.error('Request failed:', error);
        throw error;
    }
};


const callbackBtn = async (url) => {
    const response = await fetch(url);

    if (response.ok) {
        const imageBlob = await response.blob();
        const imageUrl = URL.createObjectURL(imageBlob);
        document.getElementById('map-image').src = imageUrl;
    } else {
        console.error("Ошибка загрузки карты");
    }
};

function arraysEqual(a, b) {
    let t = 0;
    for (var i = 0; i < a.length; ++i) {
        if (a[i] === b[i]) t++;
    }
    return t
};


const inputLine = document.getElementById('text-answer');
const btn = document.getElementById('answer');
const postData = { 'gamemode': 'default', 'gameModification': 'none' };
let answers = []
let rAnswers = []


function fetchData(callback) {
    makeRequest('http://127.0.0.1:5000/api/game?type=start', 'POST', postData)
        .then(data => {
            callback(data)
        });
}


function processDataLater(data) {
    let i = 0;

    data.forEach(element => { rAnswers.push(element.name.toLowerCase()) });

    callbackBtn(`http://127.0.0.1:5000/api/game-map?lat=${data[0].coords.lat}&lon=${data[0].coords.lon}`);

    btn.onclick = async () => {
        if (inputLine.value) {
            answers.push(inputLine.value.toLowerCase())
            console.log(answers)
            console.log(i)
            if (i < 4) {
                i++;
                inputLine.value = '';
                btn.classList.remove('is-null');

                callbackBtn(`http://127.0.0.1:5000/api/game-map?lat=${data[i]['coords']['lat']}&lon=${data[i]['coords']['lon']}`);
            } else {
                t = arraysEqual(answers, rAnswers)
                fetch('http://127.0.0.1:5000/api/game?type=ending', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ all: '5', right: `${t}` })
                }).then(() => { });
                document.querySelector('.first').remove();
                const El = document.createElement('span');
                El.className = 'col-b';
                El.innerHTML = 'Итоги';
                document.querySelector('.lbl h2').append(': ');
                document.querySelector('.lbl h2').append(El);
                document.querySelector('.sec').innerHTML = `
                <h2>Всего вопросов: <span class="col-b">${rAnswers.length}</span></h2> 
                <h2>Правильно угаданных: <span class="col-b">${t}</span></h2> 
                <h2>KD: <span class="col-b">${t / rAnswers.length}</span></h2>
                `;
            };
        } else {
            btn.classList.add('is-null');
        };
    }
}

fetchData(processDataLater)
