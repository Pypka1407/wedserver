const points = document.getElementById('points')


fetch('/user/info?type=point')
    .then(r => r.text())
    .then(point => {
        points.textContent = point;;
    });
